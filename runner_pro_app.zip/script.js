
const form = document.getElementById("runForm");
const historyEl = document.getElementById("history");
const achievementsEl = document.getElementById("achievements");
const planEl = document.getElementById("plan");

let runs = JSON.parse(localStorage.getItem("runnerData")) || [];

function save(){
  localStorage.setItem("runnerData", JSON.stringify(runs));
}

function totalKM(){
  return runs.reduce((a,b)=>a+b.distance,0);
}

function totalXP(){
  return Math.floor(totalKM()*10);
}

function level(){
  return Math.floor(totalXP()/100)+1;
}

function streak(){
  if(runs.length === 0) return 0;

  const sorted = [...runs]
  .sort((a,b)=>new Date(b.date)-new Date(a.date));

  let streak = 1;

  for(let i=0;i<sorted.length-1;i++){
    const current = new Date(sorted[i].date);
    const next = new Date(sorted[i+1].date);

    const diff = (current-next)/(1000*60*60*24);

    if(diff <= 1.5){
      streak++;
    } else {
      break;
    }
  }

  return streak;
}

function updateStats(){
  document.getElementById("km").textContent =
    totalKM().toFixed(1)+" KM";

  document.getElementById("xp").textContent =
    totalXP()+" XP";

  document.getElementById("level").textContent =
    level();

  document.getElementById("streak").textContent =
    streak();
}

function renderHistory(){
  historyEl.innerHTML = "";

  [...runs].reverse().forEach(run=>{
    const pace = (run.time/run.distance).toFixed(1);

    historyEl.innerHTML += `
      <tr>
        <td>${run.date}</td>
        <td>${run.distance} km</td>
        <td>${run.time} min</td>
        <td>${pace} min/km</td>
      </tr>
    `;
  });
}

function renderAchievements(){

  achievementsEl.innerHTML = "";

  const total = totalKM();

  const achievements = [];

  if(runs.length >= 1)
    achievements.push("🏅 First Run Completed");

  if(total >= 10)
    achievements.push("🔥 10KM Milestone");

  if(total >= 50)
    achievements.push("⚡ 50KM Runner");

  if(total >= 100)
    achievements.push("🚀 100KM Elite");

  if(streak() >= 7)
    achievements.push("👑 7 Day Streak");

  if(streak() >= 30)
    achievements.push("💀 Discipline Monster");

  if(runs.some(r=>r.distance >= 21))
    achievements.push("🏃 Half Marathon Completed");

  achievements.forEach(a=>{
    achievementsEl.innerHTML += `
      <div class="achievement">${a}</div>
    `;
  });

  if(achievements.length === 0){
    achievementsEl.innerHTML =
      "<div class='achievement'>No achievements yet.</div>";
  }
}

function generatePlan(){

  planEl.innerHTML = "";

  const km = totalKM();

  let base = 3;

  if(km >= 20) base = 5;
  if(km >= 50) base = 7;
  if(km >= 100) base = 10;

  const plan = [
    `Easy Run — ${base}km`,
    `Strength + Recovery`,
    `Tempo Run — ${base+2}km`,
    `Recovery Jog — ${base-1}km`,
    `Rest Day`,
    `Long Run — ${base+5}km`,
    `Easy Recovery — ${base-1}km`
  ];

  plan.forEach((item,index)=>{
    planEl.innerHTML += `
      <div class="plan-card">
        <strong>Day ${index+1}</strong><br>
        ${item}
      </div>
    `;
  });
}

form.addEventListener("submit",(e)=>{

  e.preventDefault();

  const distance =
    parseFloat(document.getElementById("distance").value);

  const time =
    parseFloat(document.getElementById("time").value);

  const date =
    new Date().toISOString().split("T")[0];

  runs.push({
    distance,
    time,
    date
  });

  save();
  renderAll();

  form.reset();
});

function renderAll(){
  updateStats();
  renderHistory();
  renderAchievements();
  generatePlan();
}

renderAll();
